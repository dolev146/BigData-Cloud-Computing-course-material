var prods={
    title:{text:"אוניברסיטת אריאל"},
    prods:[     
       {product:"ice cream",quantity:90},
       {product:"cake",quantity:220},
       {product:"chocklate",quantity:190},
       {product:"gum",quantity:290}
   ]}; 
 module.exports=prods;  