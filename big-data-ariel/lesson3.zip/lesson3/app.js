const express = require('express')
const app = express()
const port = 3000



app.get('/cake.png', (req, res) => {
    res.send('random.text')
  })

app.get('/calc/:x/:y', (req, res) => {
  result={}
  result.x=parseInt(req.params.x)
  result.y= parseInt(req.params.y)
  result.sum=result.x+result.y
  res.json(result)
})

app.use(express.static('public'))

app.get('/plantae/:genus:species', (req, res) => {
    res.send(req.params)
  })
  
app.listen(port, () => {
  console.log(`http://localhost:${port}`)
})